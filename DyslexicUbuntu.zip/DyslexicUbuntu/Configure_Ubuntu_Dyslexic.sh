#!/bin/bash
#
#Update apt && install vanilla gnome environment
#
sudo apt update
sudo apt install vanilla-gnome-desktop -y
sudo apt install vanilla-gnome-default-settings -y
sudo apt install gnome-tweaks -y
echo "Gnome Installed"
#
#
#Install Unzip && Unzip Files
#
sudo apt install unzip -y
sudo unzip 'OpenDyslexic 3 (Beta - Windows, MacOS, Linux TTF).zip'
sudo unzip 'OpenDyslexic Mono (Windows, MacOS, Linux OTF).zip'
echo "Filed Unzipped"
#
#
#Make File Directory & Install System Wide Fonts
#
sudo mkdir /usr/local/share/fonts/OpenDyslexic3
sudo cp ./OpenDyslexic3-Bold.ttf /usr/local/share/fonts/OpenDyslexic3
sudo cp ./OpenDyslexic3-Regular.ttf /usr/local/share/fonts/OpenDyslexic3
sudo cp ./OpenDyslexicMono-Regular.otf /usr/local/share/fonts/OpenDyslexic3
echo "OpenDyslexic Installed"
echo "OpenDyslexic is a an Open Source font family produced by OpenDyslexic. It is produced under the SIL-OFL Lisence, and the responsible organization website is located at https://www.opendyslexic.org"
#
#
#Make Theme Directory && Copy Files To It
#
sudo mkdir /usr/share/themes/OpenDyslexic3
sudo cp ./Graphical_Assets/Logo.png /usr/share/themes/OpenDyslexic3/
sudo cp ./Graphical_Assets/Wallpaper_Light.jpg /usr/share/themes/OpenDyslexic3
sudo cp ./Graphical_Assets/Wallpaper_Dark.png /usr/share/themes/OpenDyslexic3
sudo cp ./Graphical_Assets/ScreenSaver.jpg /usr/share/themes/OpenDyslexic3
sudo cp ./Graphical_Assets/Login.jpg /usr/share/themes/OpenDyslexic3
echo "Files Copied to /usr/share/themes/OpenDyslexic3"
#
#
#Load in Dconf Settings
#
echo ""
echo ""
echo ""
echo ""
echo ""
echo "To complete task issue the following command and then reboot"
echo "dconf load / < dconf-settings.ini"
